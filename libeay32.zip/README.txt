This file was downloaded from: http://www.dll-files.com

If you downloaded it from somewhere else, please let us now: http://www.dll-files.com/contact.php

Installation instructions: 

Open the zip-file you downloaded from DLL-files.com.

Extract the .dll-file to a location on your computer.

We recommend you to unzip the file to the directory of the program that is requesting the file. 
If that doesn't work, you will have to extract the file to your system directory. 
By default, this is C:\Windows\System (Windows 95/98/Me), C:\WINNT\System32 (Windows NT/2000), or C:\Windows\System32 (Windows XP, Vista, 7).
Make sure overwrite any existing files (but make a backup copy of the original file). 

Reboot your computer. 
If the problem still occurs, try the following: 

1. Press Start and select Run. 
2. Type CMD and press Enter (or if you use Windows ME, type COMMAND). 
3. Type regsvr32 "filename".dll and press Enter.

If you have any other problems, see our HELP-section at www.dll-files.com